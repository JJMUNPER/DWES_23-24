<?php

/**
 * 
 * Modelo: model.nuevo.php
 * Descripción: carga array categorias y array de marcas
 */


$categorias = ArrayArticulos :: getCategorias();
$marcas = ArrayArticulos :: getMarcas();


?>