<?php 

// Clases
include 'class/class.articulo.php';
include 'class/class.arrayArticulos.php';

//Libreria

include 'libs/crud_funciones.php';


// Model
include 'models/modelEliminar.php';

// Cargo la vista
include "views/viewIndex.php";



?>