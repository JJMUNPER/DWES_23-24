<?php 

// Librería
include 'libs/crud_funciones.php';

// Model
include 'models/modelMostrar.php';

// Cargo la vista
include "views/viewMostrar.php";



?>