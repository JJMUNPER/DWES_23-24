<?php 

#Controlador: create.php
#Descripción: mostrar un formulario que permita añadir nuevo libro

// Clases
include 'class/class.articulo.php';
include 'class/class.arrayArticulos.php';


//Libreria

include 'libs/crud_funciones.php';


// Model
include 'models/modelCreate.php';

// Cargo la vista
include "views/viewIndex.php";



?>