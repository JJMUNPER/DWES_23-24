<?php 

/**
 * Controlador:index.php 
 * Descripción: muestra los detalles de los artículos ordenados 
 */

include 'class/class.articulo.php';
include 'class/class.arrayArticulos.php';

include 'models/modelIndex.php';

// Cargo la vista
include "views/viewIndex.php";



?>