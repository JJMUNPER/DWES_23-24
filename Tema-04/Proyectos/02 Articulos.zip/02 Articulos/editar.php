<?php 

// Clases
include 'class/class.arrayArticulos.php';
include 'class/class.articulo.php';

//Libreria

include 'libs/crud_funciones.php';

// Model
include 'models/modelEditar.php';

// Cargo la vista
include "views/viewEditar.php";



?>