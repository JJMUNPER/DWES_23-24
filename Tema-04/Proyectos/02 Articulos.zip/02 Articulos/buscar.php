<?php 

// Librería
include 'libs/crud_funciones.php';

// Model

include 'models/modelBuscar.php';

// Cargo la vista
include "views/viewIndex.php";



?>