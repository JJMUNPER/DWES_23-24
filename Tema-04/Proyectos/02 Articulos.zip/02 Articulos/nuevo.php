<?php 

#Controlador: nuevo.php
#Descripción: mostrar un formulario que permita añadir nuevo articulo

// Librería
include 'class/class.articulo.php';
include 'class/class.arrayArticulos.php';



include 'models/modelNuevo.php';


// Cargo la vista
include "views/viewNuevo.php";



?>