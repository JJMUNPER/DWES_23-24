<?php

/**
 * 
 * calcular.php
 * 
 * Hace los calculos
 */

#clase calculadora

include "class/class.calculadora.php";

#cargo el modelo

include "models/model.calcular.php";

#cargo la vista 

include "views/view.resultado.php";

?>