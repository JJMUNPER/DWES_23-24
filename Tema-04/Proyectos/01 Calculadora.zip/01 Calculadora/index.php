<?php

#clase calculadora

include "class/class.calculadora.php";

#cargo el modelo

#cargo la vista 

include "views/view.index.php";

?>