<header class="pb-3 mb-4 border-bottom">
    <i class="bi bi-bullseye" style="font-size: 30px; color:Green"></i>
    <span class="fs-4">Proyecto 4.1 Calculadora POO</span>
</header>