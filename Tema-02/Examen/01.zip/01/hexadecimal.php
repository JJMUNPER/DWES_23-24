<?php

    /*

        Controlador: hexadecimal.php
        Descripción: pasa de decimal a hexadecimal

    */

    # Model
    include 'models/modelHexadecimal.php';

    # Vista
    include 'views/viewResultado.php';

?>