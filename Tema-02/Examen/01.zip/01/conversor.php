<?php

    /*

        Controlador: conversor.php
        Descripción: realiza las operaciones de conversión

    */

    # Model
    include 'models/modelConversor.php';

    # Vista
    include "views/viewConversor.php";

?>