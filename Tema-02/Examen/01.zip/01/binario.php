<?php

    /*

        Controlador: binario.php
        Descripción: pasa de decimal a binario

    */

    # Model
    include 'models/modelBinario.php';

    # Vista
    include 'views/viewResultado.php';

?>