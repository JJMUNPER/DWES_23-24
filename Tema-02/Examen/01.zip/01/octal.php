<?php

    /*

        Controlador: octal.php
        Descripción: pasa de decimal a octal

    */

    # Model
    include 'models/modelOctal.php';

    # Vista
    include 'views/viewResultado.php';

?>