<?php

$operacion = "octal";
$valorDecimal = $_POST['valorDecimal'];

$valorOctal = decoct($valorDecimal);
$valor = $valorOctal;


?>