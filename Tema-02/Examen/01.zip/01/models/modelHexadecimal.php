<?php

$operacion = "Hexadecimal";
$valorDecimal = $_POST['valorDecimal'];

$valorHexadecimal = dechex($valorDecimal);
$valor = $valorHexadecimal;

?>