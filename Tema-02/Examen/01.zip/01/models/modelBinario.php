<?php


$operacion = "Binario";
$valorDecimal = $_POST['valorDecimal'];

$valorBinario = decbin($valorDecimal);
$valor = $valorBinario;

?>