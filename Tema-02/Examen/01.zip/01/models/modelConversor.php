<?php

$valorDecimal = $_POST['valorDecimal'];

$valorBinario = decbin($valorDecimal);
$valorOctal = decoct($valorDecimal);
$valorHexadecimal = dechex($valorDecimal);


?>