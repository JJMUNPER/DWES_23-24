<?php

/**
 * Ejercicio 4: empty()
 */

$valor4 = 1;
$valor5 = 2;
$valor6 = 3;


var_dump(empty($valor1));
echo "<br>";
var_dump(empty($valor2));
echo "<br>";
var_dump(empty($valor3));
echo "<br>";
var_dump(empty($valor4));
echo "<br>";
var_dump(empty($valor5));
echo "<br>";
var_dump(empty($valor6));
echo "<br>";

?>