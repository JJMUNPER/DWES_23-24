<?php

/**
 * Actividad 3: isset()
 */

$valor1 = 0;
$valor2 = 1;
$valor3 = "";
$valor4 = null;


var_dump(isset($valor1));
echo "<br>";
var_dump(isset($valor2));
echo "<br>";
var_dump(isset($valor3));
echo "<br>";
var_dump(isset($valor4));
echo "<br>";
var_dump(isset($valor5));
echo "<br>";
var_dump(isset($valor6));
echo "<br>";

?>