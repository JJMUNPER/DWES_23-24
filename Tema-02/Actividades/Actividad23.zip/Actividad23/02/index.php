<?php

/**
 * Ejercicio 2: is_null()
 * 
 */

$valor1 = 5;
$valor2 = "Hola";
$valor3 = true;
$valor4="";
$valor5 = null;
$valor6=false;

var_dump(is_null($valor1));
echo "<br>";
var_dump(is_null($valor2));
echo "<br>";
var_dump(is_null($valor3));
echo "<br>";
var_dump(is_null($valor4));
echo "<br>";
var_dump(is_null($valor5));
echo "<br>";
var_dump(is_null($valor6));
echo "<br>";




?>