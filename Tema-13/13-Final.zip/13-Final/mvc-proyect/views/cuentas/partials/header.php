<header>
    <hgroup>
        <!-- Titulos y subtitulos -->
        <div class="jumbotron jumbotron-fluid">
        <i class="bi bi-envelope-at"></i>
                <h4 class="display-7"><?= $this->title ?> </h4>
            </div>
        </div>
    </hgroup>
</header>