<header class="pb-3 mb-4 border-bottom">
<i class="bi bi-coin"></i>       
    <span class="fs-4"><?= $this->title ?></span>
           
</header>