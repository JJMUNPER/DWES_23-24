<?php

require_once 'class/class.pdfCuentas.php';

class Cuentas extends Controller
{

    # Método render
    # Principal del controlador Cuentas, muestra los detalles
    function render($param = [])
    {
        //-----------------------------Validación/Auten/gestion------------------------///

        # Iniciamos o continuamos la sesión
        session_start();

        # Comprobamos si el usuario está autentificado
        if (!isset($_SESSION['id'])) {
            // Añadimo el siguiente aviso al usuario: 
            $_SESSION['mensaje'] = "Usuario debe autentificarse";

            // Redireccionamos al login
            header('location:' . URL . 'login');
        } else if (!in_array($_SESSION['id_rol'], $GLOBALS['clientes']['main'])) {
            // Mensaje al usuario
            $_SESSION['mensaje'] = "No tienes privilegios para realizar dicha operación";

            // Redireccionamos
            header('location:' . URL . 'index');
        } else {

            # Si existe un mensaje, lo mostramos
            if (isset($_SESSION['mensaje'])) {
                // Añadimos a la vista el mensaje
                $this->view->mensaje = $_SESSION['mensaje'];
                // Destruimos el mensaje
                unset($_SESSION['mensaje']);
            }
            //-----------------------------------------------------------------//

            $this->view->title = "Tabla Cuentas";
            $this->view->cuentas = $this->model->get();
            $this->view->render("cuentas/main/index");
        }
    }

    # Método nuevo
    # Permite mostrar un formulario que permita añadir una nueva cuenta
    function nuevo($param = [])
    {
        //-----------------------------Validación/Aut/Gestion------------------------///

        # Iniciamos o continuamos la sesión
        session_start();

        # Comprobamos si el usuario está autentificado
        if (!isset($_SESSION['id'])) {
            // Añadimo el siguiente aviso al usuario: 
            $_SESSION['mensaje'] = "Usuario debe autentificarse";

            // Redireccionamos al login
            header('location:' . URL . 'login');
        } else if (!in_array($_SESSION['id_rol'], $GLOBALS['clientes']['new'])) {
            // Mensaje al usuario
            $_SESSION['mensaje'] = "No tienes privilegios para realizar dicha operación";

            // Redireccionamos
            header('location:' . URL . 'cuentas');
        } else {

            # Creamos un objeto vacío
            $this->view->cuenta = new classCuenta();

            # Comprobamos si existen errores
            if (isset($_SESSION['error'])) {

                // Añadimos a la vista el mensaje de error
                $this->view->error = $_SESSION['error'];

                // Autorellenamos el formulario
                $this->view->cuenta = unserialize($_SESSION['cuenta']);

                // Recuperamos el array
                $this->view->errores = $_SESSION['errores'];

                // Eliminamos variables de sesion
                unset($_SESSION['error']);
                unset($_SESSION['errores']);
                unset($_SESSION['cuenta']);
            }

            //-----------------------------------------------------------------//

            $this->view->title = "Formulario añadir cuenta";

            // Para generar la lista select dinámica de clientes
            $this->view->clientes = $this->model->getClientes();

            $this->view->render("cuentas/nuevo/index");
        }
    }

    # Método create
    # Envía los detalles para crear una nueva cuenta
    function create($param = [])
    {
        # Iniciamos o continuamos la sesión
        session_start();

        # Comprobamos si el usuario está autentificado
        if (!isset($_SESSION['id'])) {
            // feedback usuario
            $_SESSION['mensaje'] = "Usuario debe autentificarse";

            // Redireccionamos al login
            header('location:' . URL . 'login');
        } else if (!in_array($_SESSION['id_rol'], $GLOBALS['clientes']['delete'])) {
            // Mensaje al usuario
            $_SESSION['mensaje'] = "No tienes privilegios para realizar dicha operación";

            // Redireccionamos
            header('location:' . URL . 'cuentas');
        } else {

            # 1. Saneamiento de los datos del formulario
            $num_cuenta = filter_var($_POST['num_cuenta'] ??= '', FILTER_SANITIZE_SPECIAL_CHARS);
            $id_cliente = filter_var($_POST['id_cliente'] ??= '', FILTER_SANITIZE_NUMBER_INT);
            $fecha_alta = filter_var($_POST['fecha_alta'] ??= '', FILTER_SANITIZE_SPECIAL_CHARS);
            $saldo = filter_var($_POST['saldo'] ??= '', FILTER_SANITIZE_SPECIAL_CHARS);

            # 2. Creamos un objeto nuevo de cuenta(clase)
            $cuenta = new classCuenta(
                null,
                $num_cuenta,
                $id_cliente,
                $fecha_alta,
                date("d-m-Y H:i:s"),
                0,
                $saldo,
                null,
                null
            );

            # 3. Validación
            $errores = [];

            // Cuenta Bancaria. Obligado con expresion regular
            $cuenta_regexp = [
                'options' => [
                    'regexp' => '/^[0-9]{20}$/'
                ]
            ];
            if (empty($num_cuenta)) {
                $errores['num_cuenta'] = 'Campo Obligatorio';
            } else if (!filter_var($num_cuenta, FILTER_VALIDATE_REGEXP, $cuenta_regexp)) {
                $errores['num_cuenta'] = 'Formato no valido, deben ser 20 caracteres númericos';
            } else if (!$this->model->validateUniqueNumCuenta($num_cuenta)) {
                $errores['num_cuenta'] = "Numero de cuenta existente";
            }

            // Cliente. Obligado
            if (empty($id_cliente)) {
                $errores['id_cliente'] = 'Campo Obligatorio';
            } else if (!filter_var($id_cliente, FILTER_VALIDATE_INT)) {
                $errores['id_cliente'] = 'Deberá introducir un valor númerico en este campo';
            } else if (!$this->model->validateCliente($id_cliente)) {
                $errores['id_cliente'] = 'No existe el cliente indicado';
            }

            // Fecha alta. Obligado
            if (empty($fecha_alta)) {
                $errores['fecha_alta'] = 'Campo Obligatorio';
            } else if (!$this->model->validateFecha($fecha_alta)) {
                $errores['fecha_alta'] = 'El formato es incorrecto';
            }

            ##Saldo##
            if (empty($saldo)) {
                $errores['saldo'] = 'El campo saldo es obligatorio';
            } else if (!is_numeric($saldo)) {
                $errores['saldo'] = 'El campo saldo debe ser numérico';
            }

            # 4. Comprobar validación
            if (!empty($errores)) {
                // Errores de validación
                $_SESSION['cuenta'] = serialize($cuenta);
                $_SESSION['error'] = 'Formulario no validado';
                $_SESSION['errores'] = $errores;

                // Redireccionamos al formulario
                header('location:' . URL . 'cuentas/nuevo/index');
            } else {
                # Añadimos el registro a la tabla
                $this->model->create($cuenta);

                // Feedback
                $_SESSION['mensaje'] = "Cuenta creada correctamente.";

                // Redirecciono
                header("Location:" . URL . "cuentas");
            }
        }
    }

    # Método delete
    # Permite eliminar una cuenta de la tabla
    function delete($param = [])
    {
        //---------------Auten/gestion----------------------//
        # Iniciamos o continuamos sesión
        session_start();

        # Comprobamos si el usuario está autentificado
        if (!isset($_SESSION['id'])) {
            // Feedback usuario
            $_SESSION['mensaje'] = "Usuario debe autentificarse";

            // Redirecciono
            header('location:' . URL . 'login');
        } else if (!in_array($_SESSION['id_rol'], $GLOBALS['clientes']['new'])) {
            // Feedback usuario
            $_SESSION['mensaje'] = "No tienes privilegios para realizar dicha operación";

            // Redireccionamos
            header('location:' . URL . 'cuentas');
        } else {
            $id = $param[0];
            $this->model->delete($id);
            header("Location:" . URL . "cuentas");
        }
        //------------------------------//
    }

    # Método editar
    function editar($param = [])
    {
        //-----------------Validacion/autentificación/Gestion-----------//
        # Iniciamos o continuamos la sesión
        session_start();

        # Comprobamos si el usuario está autentificado
        if (!isset($_SESSION['id'])) {
            // Mensaje usuario 
            $_SESSION['mensaje'] = "Usuario debe autentificarse";

            // Redirecciono
            header('location:' . URL . 'login');
        } else if (!in_array($_SESSION['id_rol'], $GLOBALS['cuentas']['edit'])) {
            //Feedback usuario
            $_SESSION['mensaje'] = "No tienes privilegios para realizar dicha operación";

            // Redirecciono
            header('location:' . URL . 'cuentas');
        } else {

            # Obtengo el id de la cuenta a editar
            $id = $param[0];

            # Asignamos dicho id a una propiedad de la vista
            $this->view->id = $id;

            # Comprobamos si el formulario viene de una no validación
            if (isset($_SESSION['error'])) {
                // Añadimos a la vista en el mensaje de error
                $this->view->error = $_SESSION['error'];

                // Autorellenamos el formulario
                $this->view->cuenta = unserialize($_SESSION['cuenta']);

                // Recuperamos el array con los errores
                $this->view->errores = $_SESSION['errores'];

                // Eliminamos variables sesion
                unset($_SESSION['error']);
                unset($_SESSION['errores']);
                unset($_SESSION['cuenta']);

            }

            $this->view->title = "Formulario editar cuenta";
            $this->view->clientes = $this->model->getClientes();
            $this->view->cuenta = $this->model->getCuenta($id);

            // // formateamos la fecha
            // $fechaf=(str_split($this->view->cuenta->fecha_alta));
            // for ($i=0; $i <9 ; $i++) { 
            //     array_pop($fechaf);
            // }
            // $fechafort=implode($fechaf);
            // $this->view->cuenta->fecha_alta=$fechafort;

            $this->view->render("cuentas/editar/index");
        }
        //-------------------------------------------------------//
    }

    # Método update
    # Envía los detalles modificados de una cuenta para su actualización en la tabla
    function update($param = [])
    {
        # Iniciamos o continuamos la sesión
        session_start();

        # Comprobamos si el usuario está autentificado
        if (!isset($_SESSION['id'])) {
            // Feedback usuario 
            $_SESSION['mensaje'] = "Usuario debe autentificarse";

            // Redirecciono
            header('location:' . URL . 'login');
        } else if (!in_array($_SESSION['id_rol'], $GLOBALS['cuentas']['edit'])) {
            //Feedback usuario
            $_SESSION['mensaje'] = "No tienes privilegios para realizar dicha operación";

            // Redirecciono 
            header('location:' . URL . 'cuentas');
        } else {

            # 1. Saneamos los datos del formulario
            $num_cuenta = filter_var($_POST['num_cuenta'] ??= '', FILTER_SANITIZE_SPECIAL_CHARS);
            $id_cliente = filter_var($_POST['id_cliente'] ??= '', FILTER_SANITIZE_NUMBER_INT);
            $num_movimientos = filter_var($_POST['num_movtos'] ??= '', FILTER_SANITIZE_SPECIAL_CHARS);
            $fechaUltMovimiento = filter_var($_POST['fecha_ul_mov'] ??= '', FILTER_SANITIZE_SPECIAL_CHARS);
            $fecha_alta = filter_var($_POST['fecha_alta'] ??= '', FILTER_SANITIZE_SPECIAL_CHARS);
            $saldo = filter_var($_POST['saldo'] ??= '', FILTER_SANITIZE_SPECIAL_CHARS);

            # 2. Creamos el objeto cuenta, a partir de los datos saneados del formulario
            $cuenta = new classCuenta(
                null,
                $num_cuenta,
                $id_cliente,
                $fecha_alta,
                date("d-m-Y H:i:s"),
                0,
                $saldo,
                null,
                null
            );

            // Cargamos el id de la cuenta a actualizar
            $id = $param[0];

            # Obtenemos el objeto original (ClassCuenta->getCuenta)
            $original = $this->model->getCuenta($id);


            # 3. Validación

            // Solo si es necesario y en caso de modificación del campo
            $errores = [];

            // Valida NºCuenta
            if (strcmp($num_cuenta, $original->num_cuenta) !== 0) {
                $cuenta_regexp = [
                    'options' => [
                        'regexp' => '/^[0-9]{20}$/'
                    ]
                ];
                if (empty($num_cuenta)) {
                    $errores['num_cuenta'] = 'Campo Obligatorio, añada un número de cuenta';
                } else if (!filter_var($num_cuenta, FILTER_VALIDATE_REGEXP, $cuenta_regexp)) {
                    $errores['num_cuenta'] = 'Formato no valido, deben ser 20 caracteres númericos';
                } else if (!$this->model->validateUniqueNumCuenta($num_cuenta)) {
                    $errores['num_cuenta'] = "El número de cuenta ya está registrado";
                }
            }

            // Validar Cliente
            if (strcmp($id_cliente, $original->id_cliente) !== 0) {
                if (empty($id_cliente)) {
                    $errores['id_cliente'] = 'Campo Obligatorio, seleccione un cliente';
                } else if (!filter_var($id_cliente, FILTER_VALIDATE_INT)) {
                    $errores['id_cliente'] = 'Deberá introducir un valor númerico en este campo';
                } else if (!$this->model->validateCliente($id_cliente)) {
                    $errores['id_cliente'] = 'No existe el cliente indicado';
                }
            }

            // Validar Fcha Alta
            // if (strcmp($fecha_alta, $original->fecha_alta) !== 0) {
            //     if (empty($fecha_alta)) {
            //         $errores['fecha_alta'] = 'Campo Obligatorio, añada una fecha';
            //     } else if (!$this->model->validateFecha($fecha_alta)) {
            //         $errores['fecha_alta'] = 'La fecha no tiene el formato correcto';
            //     }
            // }

            // Validamos Ultimo movimiento
            // if (strcmp($fechaUltMovimiento, $original->fecha_ul_mov)) {
            //     if (!empty($fechaUltMovimiento && !$this->model->validateFecha($fechaUltMovimiento))) {
            //         $errores['fecha_ul_mov'] = 'La fecha no tiene el formato correcto';
            //     }
            // }

            # 4. Comprobar validación
            if (!empty($errores)) {
                // Errores 
                $_SESSION['cuenta'] = serialize($cuenta);
                $_SESSION['error'] = 'Formulario no validado';
                $_SESSION['errores'] = $errores;

                // Redireccionamos
                header('location:' . URL . 'cuentas/editar/' . $id);
            } else {
                // Actualizamos el registro 
                $this->model->update($cuenta, $id);

                // Feedback
                $_SESSION['mensaje'] = 'Se ha actualizado la cuenta con éxito';

                // Redireccionamos 
                header("Location:" . URL . "cuentas");
            }
        }
    }


    # Método mostrar
    # Muestra los detalles de una cuenta en un formulario no editable
    function mostrar($param = [])
    {
        # Iniciamos o continuamos sesión
        session_start();

        # Comprobamos si el usuario está autentificado
        if (!isset($_SESSION['id'])) {
            // Añadimo el siguiente aviso al usuario: 
            $_SESSION['mensaje'] = "Usuario debe autentificarse";

            // Redireccionamos al login
            header('location:' . URL . 'login');
        } else if (!in_array($_SESSION['id_rol'], $GLOBALS['cuentas']['show'])) {
            //Feedback usuario
            $_SESSION['mensaje'] = "No tienes privilegios para realizar dicha operación";

            // Redirecciono
            header('location:' . URL . 'cuentas');
        } else {
            # id de la cuenta
            $id = $param[0];

            $this->view->title = "Formulario Cuenta Mostar";
            $this->view->cuenta = $this->model->getCuenta($id);
            $this->view->cliente = $this->model->getCliente($this->view->cuenta->id_cliente);

            // // formateamos la fecha
            // $fechaf=(str_split($this->view->cuenta->fecha_alta));
            // for ($i=0; $i <9 ; $i++) { 
            //     array_pop($fechaf);
            // }
            // $fechafort=implode($fechaf);
            // $this->view->cuenta->fecha_alta=$fechafort;

            $this->view->render("cuentas/mostrar/index");
        }
    }

    # Método ordenar
    # Permite ordenar la tabla cuenta a partir de alguna de las columnas de la tabla
    function ordenar($param = [])
    {
        # Iniciamos o continuamos sesión
        session_start();

        # Comprobamos si el usuario está autentificado
        if (!isset($_SESSION['id'])) {
            // Añadimo el siguiente aviso al usuario: 
            $_SESSION['mensaje'] = "Usuario debe autentificarse";

            // Redireccionamos al login
            header('location:' . URL . 'login');
        } else if (!in_array($_SESSION['id_rol'], $GLOBALS['cuentas']['order'])) {
            // Feedback usuario
            $_SESSION['mensaje'] = "No tienes privilegios para realizar dicha operación";

            // Redirecciono
            header('location:' . URL . 'cuentas');
        } else {
            $criterio = $param[0];
            $this->view->title = "Tabla Cuentas";
            $this->view->cuentas = $this->model->order($criterio);
            $this->view->render("cuentas/main/index");
        }
    }

    # Método buscar
    # Permite realizar una búsqueda en la tabla cuentas a partir de una expresión
    function buscar($param = [])
    {
        # Iniciamos o continuamos sesión
        session_start();

        # Comprobamos si el usuario está autentificado
        if (!isset($_SESSION['id'])) {
            // Añadimo el siguiente aviso al usuario: 
            $_SESSION['mensaje'] = "Usuario debe autentificarse";

            // Redireccionamos al login
            header('location:' . URL . 'login');
        } else if (!in_array($_SESSION['id_rol'], $GLOBALS['cuentas']['filter'])) {
            // Feedback usuario
            $_SESSION['mensaje'] = "No tienes privilegios para realizar dicha operación";

            // Redirecciono
            header('location:' . URL . 'cuentas');
        } else {
            $expresion = $_GET["expresion"];
            $this->view->title = "Tabla Cuentas";
            $this->view->cuentas = $this->model->filter($expresion);
            $this->view->render("cuentas/main/index");
        }
    }

    //CSV//No obligatorio
    #Exportar
    public function exportar()
    {
        session_start();

        if (!isset($_SESSION['id'])) {
            $_SESSION['mensaje'] = "Usuario no autentificado";
            header("location:" . URL . "login");
        } else if ((!in_array($_SESSION['id_rol'], $GLOBALS['cuentas']['exportar']))) {
            $_SESSION['mensaje'] = "Operación sin privilegios";
            header('location:' . URL . 'cuentas');
        }

        $cuentas = $this->model->getCSV()->fetchAll(PDO::FETCH_ASSOC);

        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="cuentas.csv"');

        $ficheroExport = fopen('php://output', 'w');

        // Iterar sobre las cuentas y escribir los datos en el archivo CSV
        foreach ($cuentas as $cuenta) {

            $fecha = date("Y-m-d H:i:s");

            $cuenta['create_at'] = $fecha;
            $cuenta['update_at'] = $fecha;

            $cuenta = array(
                'num_cuenta' => $cuenta['num_cuenta'],
                'id_cliente' => $cuenta['id_cliente'],
                'fecha_alta' => $cuenta['fecha_alta'],
                'fecha_ul_mov' => $cuenta['fecha_ul_mov'],
                'num_movtos' => $cuenta['num_movtos'],
                'saldo' => $cuenta['saldo'],
                'create_at' => $cuenta['create_at'],
                'update_at' => $cuenta['update_at']
            );

            fputcsv($ficheroExport, $cuenta, ';');
        }

        fclose($ficheroExport);
    }

    #Importar
    public function importar()
    {
        session_start();

        if (!isset($_SESSION['id'])) {
            $_SESSION['mensaje'] = "Usuario no autentificado";
            header("location:" . URL . "login");
            exit();
        } else if ((!in_array($_SESSION['id_rol'], $GLOBALS['cuentas']['importar']))) {
            $_SESSION['mensaje'] = "Operación sin privilegios";
            header('location:' . URL . 'cuentas');
            exit();
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["archivo_csv"]) && $_FILES["archivo_csv"]["error"] == UPLOAD_ERR_OK) {
            $file = $_FILES["archivo_csv"]["tmp_name"];

            $handle = fopen($file, "r");

            if ($handle !== FALSE) {
                while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) {
                    $num_cuenta = $data[0];
                    $id_cliente = $data[1];
                    $fecha_alta = $data[2];
                    $fecha_ul_mov = $data[3];
                    $num_movtos = $data[4];
                    $saldo = $data[5];

                    //Método para verificar número de cuenta único.
                    if ($this->model->validateUniqueNumCuenta($num_cuenta)) {
                        // Si no existe, crear una nueva cuenta
                        $cuenta = new classCuenta();
                        $cuenta->num_cuenta = $num_cuenta;
                        $cuenta->id_cliente = $id_cliente;
                        $cuenta->fecha_alta = $fecha_alta;
                        $cuenta->fecha_ul_mov = $fecha_ul_mov;
                        $cuenta->num_movtos = $num_movtos;
                        $cuenta->saldo = $saldo;

                        //Usamos create para meter la cuenta en la base de datos
                        $this->model->create($cuenta);
                    } else {
                        //Error de cuenta existente
                        echo "Error, esta cuenta ya existe en la base de datos";
                    }
                }

                fclose($handle);
                $_SESSION['mensaje'] = "Importación realizada correctamente";
                header('location:' . URL . 'cuentas');
                exit();
            } else {
                $_SESSION['error'] = "Error con el archivo CSV";
                header('location:' . URL . 'cuentas');
                exit();
            }
        } else {
            $_SESSION['error'] = "Seleccione un archivo CSV";
            header('location:' . URL . 'cuentas');
            exit();
        }
    }

    //PDF// No obligatorio

    function pdf()
    {
        session_start();

        if (!isset($_SESSION['id'])) {
            $_SESSION['mensaje'] = "Usuario no autentificado";
            header("location:" . URL . "login");
            exit();
        } else if ((!in_array($_SESSION['id_rol'], $GLOBALS['cuentas']['pdf']))) {
            $_SESSION['mensaje'] = "Operación sin privilegios";
            header('location:' . URL . 'cuentas');
            exit();
        }

        //Obtenemos las cuentas con get
        $cuentas = $this->model->get();

        //Instanciamos la clase pdfCuentas
        $pdf = new pdfCuentas();

        //Escribimos en el PDF
        $pdf->contenido($cuentas);

        // Salida del PDF
        $pdf->Output();
    }

    # Método listarMovimientos
    # Muestra los movimientos de una cuenta en una vista
    function listaMovimientos($param = [])
    {

        //Iniciar o continuar sesión
        session_start();

        # id de la cuenta
        $id = $param[0];

        //Comprobar si el usuario está identificado
        if (!isset($_SESSION['id'])) {
            $_SESSION['mensaje'] = "Usuario No Autentificado";

            header("location:" . URL . "login");
        } else if ((!in_array($_SESSION['id_rol'], $GLOBALS['cuentas']['listaMovimientos']))) {
            $_SESSION['mensaje'] = "Operación sin privilegios";
            header('location:' . URL . 'cuentas');
        } else {

            $this->view->title = "Formulario Cuenta Listar Movimientos";
            $this->view->movimientos = $this->model->getMovientosCuenta($id);

            $this->view->render("cuentas/listaMovimientos/index");
        }
    }
}
