<header class="pb-3 mb-4 border-bottom">
    <i class="bi bi-journal-code" style="font-size: 3rem; color: cornflowerblue;"></i>        
    <span class="fs-4">Examen Práctico 5.1 - Gestión Libros - PDO</span>
</header>