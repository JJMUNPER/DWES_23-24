<?php
    /* 
     * db.php
     * 
     * Definimos una serie de constantes, empleadas para ser invocadas dentro del proyecto 
    */
    define('SERVER','localhost');
    define('USER','root');
    define('PASS',null);
    define('BD','maratoon');
    define('CHARSET','utf8mb4');
    define('COLLECTION','utf8mb4_unicode_ci');
?>