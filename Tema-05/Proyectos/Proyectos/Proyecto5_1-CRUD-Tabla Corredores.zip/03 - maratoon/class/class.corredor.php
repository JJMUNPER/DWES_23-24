<?php
    /** 
     * Class Corredor
     * 
     * Clase creada para instaciar objetos de esta clase
    */
    class Corredor{
        public $nombre;
        public $apellidos;
        public $ciudad;
        public $fechaNacimiento;
        public $sexo;
        public $email;
        public $dni;
        public $id_categoria;
        public $id_club;
    }
?>