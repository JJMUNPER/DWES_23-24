<?php

    /*
        Clase Curso 

        Base de datos fp
    */

    Class Curso {
    
        public $id;
        public $nombre; 
        public $ciclo;
        public $nombreCorto; 
        public $nivel;
    }
    

?>