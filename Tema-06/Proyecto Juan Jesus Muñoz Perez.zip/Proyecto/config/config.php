<?php
# Configuración básica aplicación MVC

# Ruta absoluta
// define('URL', 'http://localhost/dwes/tema-07/Practicas1920/ejemplo/');

//define('URL', 'http://localhost/dwes/tema-07/mvc-articulos/');

define('URL', 'http://localhost/dwes/Tema-06/Proyecto/02/mvc-proyect/');

# Constante de la Base de Datos
define('HOST', 'localhost');
define('DB', 'gesbank');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');


?>