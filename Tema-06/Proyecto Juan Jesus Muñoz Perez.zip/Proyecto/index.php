<?php  

require 'libs/database.php';
require 'libs/controller.php';
require 'libs/model.php';
require 'libs/view.php';
require 'class/class.cliente.php';

require 'libs/app.php';
require 'config/config.php';
$app = new App();


?>