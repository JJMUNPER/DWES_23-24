<header>
    <hgroup>
        <!-- Titulos y subtitulos -->
        <div class="jumbotron jumbotron-fluid">
        <div class="container">
            <h4 class="display-7">Gestión Alumnos - FP - MVC </h4>
            <p class="lead">Tema 7 - DWES - Curso 23/24</p>
        </div>
        </div>
    </hgroup>
</header>