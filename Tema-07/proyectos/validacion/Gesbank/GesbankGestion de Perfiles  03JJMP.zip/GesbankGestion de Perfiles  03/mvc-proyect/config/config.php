<?php
# Configuración básica aplicación MVC

# Ruta absoluta
define('URL', 'http://localhost/DWES/Tema-07/proyectos/validacion/Gesbank/GesbankGestion%20de%20Perfiles%20%2003/mvc-proyect/');

# Constante de la Base de Datos
define('HOST', 'localhost');
define('DB', 'gesbank');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');


?>