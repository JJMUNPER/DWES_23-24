<?php
# Configuración básica aplicación MVC

# Ruta absoluta

define('URL', 'http://localhost/dwes/tema-07/proyectos/validacion/01/');

# Constante de la Base de Datos
define('HOST', 'localhost');
define('DB', 'fp');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');


?>