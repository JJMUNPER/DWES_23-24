<header class="pb-3 mb-4 border-bottom">
    <i class="bi bi bi-boombox-fill" style="font-size: 3rem; color: cornflowerblue;"></i>        
    <span class="fs-4">Proyecto 5.2 Gestión Alumnos PDO</span>
</header>